package cn.zhiyou.enums;

/**
 * @author wcp
 * @since 2024/3/4
 */
public enum PopupTypeEnum {

    info,
    waring,
    error

}
