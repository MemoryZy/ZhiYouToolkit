package cn.zhiyou.enums;

/**
 * @author wcp
 * @since 2024/3/6
 */
public enum CreateMapperTextFieldEnum {

    module,

    mapper,

    class_,

    xml;

}
