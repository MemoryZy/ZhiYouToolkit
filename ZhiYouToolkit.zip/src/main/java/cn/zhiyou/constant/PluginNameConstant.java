package cn.zhiyou.constant;

import com.intellij.database.psi.DbTable;

/**
 * @author wcp
 * @since 2024/2/4
 */
public class PluginNameConstant {

    public static final String DB_TABLE_CLASS_NAME = "com.intellij.database.psi.DbTable";


}
